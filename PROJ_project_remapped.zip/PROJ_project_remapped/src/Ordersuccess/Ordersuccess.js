import React from "react";
import "./Ordersuccess.css";

function Ordersuccess() {
  return (
    <div className="background_checkot_success">
      <div className="order_page_success">
        Your order is successfully placed..
      </div>
      <div className="order_page_success_1">
        Thanks for shopping on StudyRoom.live Merchandise Store
      </div>
    </div>
  );
}

export default Ordersuccess;
