import React from "react";
import ReactDOM from "react-dom";

import App from "./App";

import * as serviceWorker from "./serviceWorker";
import { Stateprovider } from "./Context-api/StateProvider";
import reducer, { initialState } from "./Context-api/reducer";

ReactDOM.render(
  <Stateprovider initialState={initialState} reducer={reducer}>
    <App />
  </Stateprovider>,
  document.getElementById("root")
);

serviceWorker.unregister();
