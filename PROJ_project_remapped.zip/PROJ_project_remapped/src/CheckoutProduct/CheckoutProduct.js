import React, { useState } from "react";
import "./CheckoutProduct.css";
import { useStateValue } from "../Context-api/StateProvider";

function CheckoutProduct({ id, title, image, price, rating, quantity }) {
  const [state, dispatch] = useStateValue();

  const remove = (event) => {
    event.preventDefault();
    dispatch({
      type: "REMOVE_FROM_BASKET",
      items: {
        id,
        title,
        price,
        image,
        rating,
        quantity: 1,
      },
    });
  };
  const add = (event) => {
    event.preventDefault();
    console.log(id, title, price, image, rating);
    dispatch({
      type: "ADD_TO_BASKET",
      items: {
        id,
        title,
        price,
        image,
        rating,
      },
    });
  };

  return (
    <div className="checkoutProduct">
      <img src={image} alt="" className="checkout_image" />
      <div className="checkouproinfo">
        <p className="check_title"> {title}</p>
        <p className="check_price">
          <button className="pc_button" onClick={remove}>
            -
          </button>

          <strong>{quantity}</strong>
          <button className="pc_button" onClick={add}>
            +
          </button>
        </p>

        <strong className="proprice">₹{price * quantity}</strong>
      </div>
    </div>
  );
}

export default CheckoutProduct;
