import React from "react";
import Header from "./Header/Header";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link,
  Redirect,
} from "react-router-dom";
import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import Banner from "./Banner/banner";
import Checkout from "./Checkout/checkout";
import Login from "./Login/login";
import Ordersuccess from "./Ordersuccess/Ordersuccess";

function App() {
  return (
    <Router>
      <Switch>
        <Route exact path="/">
          <Redirect to="/home" />
        </Route>
        <Route path="/home">
          <Header />
          <Banner />
        </Route>
        <Route path="/checkout">
          <Header />
          <Checkout />
        </Route>
        <Route path="/login">
          <Header />
          <Login />
        </Route>

        <Route path="/order_success">
          <Header />
          <Ordersuccess />
        </Route>
      </Switch>
    </Router>
  );
}

export default App;
