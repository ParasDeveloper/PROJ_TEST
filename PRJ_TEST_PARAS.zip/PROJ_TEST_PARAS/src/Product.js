import React from "react";
import "./Product.css";
import { useStateValue } from "./StateProvider";

function Product({ id, title, price, rating, image }) {
  const [state, dispatch] = useStateValue();

  const addToBasket = (event) => {
    event.preventDefault();
    dispatch({
      type: "ADD_TO_BASKET",
      items: {
        id,
        title,
        price,
        rating,
        image,
        quantity: 1,
      },
    });
  };

  return (
    <div className="product">
      <img src={image} className="product_image" />
      <h1>{title}</h1>

      <div className="product_price">
        <small>Rs</small>
        <span>{price}</span>
      </div>

      <div className="product_rating">
        {Array(rating)
          .fill()
          .map((_, i) => (
            <p key={i}>☆</p>
          ))}
      </div>
      <button onClick={addToBasket}>Add to Cart</button>
    </div>
  );
}

export default Product;
