import React, { useState, useEffect } from "react";
import "./banner.css";
import Product from "./Product";
import {
  Nav,
  Navbar,
  NavDropdown,
  FormControl,
  Button,
  Form,
  Carousel,
} from "react-bootstrap";

function Banner() {
  var x = 0;

  useEffect(() => {
    getprod();
  }, []);
  const [datap, setdatap] = useState([]);

  ///loading dummy products
  const getprod = () => {
    console.log("useEffect called");

    setdatap([
      {
        _id: "1234",
        name: "Tshirt",
        price: 200,
        rating: 5,
        image:
          "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=800&q=80",
      },
      {
        _id: "5678",
        name: "Tshirt",
        price: 500,
        rating: 3,
        image:
          "https://images.unsplash.com/photo-1512327428889-607eeb19efe8?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      },
      {
        _id: "4444",
        name: "Tshirt",
        price: 900,
        rating: 4,
        image:
          "https://images.unsplash.com/photo-1496056013337-d6a1dd4fb8a3?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=636&q=80",
      },
      {
        _id: "6767",
        name: "Tshirt",
        price: 700,
        rating: 2,
        image:
          "https://images.unsplash.com/photo-1484517062256-430351efcbcf?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=600&q=60",
      },
    ]);
  };

  // console.log(datap)
  return (
    <div className="main-class-back">
      <div className="banroot">
        <Carousel>
          <Carousel.Item>
            <img
              className="d-block w-100"
              src="https://images.hdqwalls.com/download/girl-style-shoes-jeans-1280x300.jpg"
              alt="First slide"
            />
            <Carousel.Caption>
              {/* <h3>First slide label</h3>
            <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p> */}
            </Carousel.Caption>
          </Carousel.Item>
          <Carousel.Item>
            <img
              className="d-block w-100"
              src="https://images.hdqwalls.com/download/hanging-shoes-in-air-city-night-view-4k-v5-1280x300.jpg"
              alt="Third slide"
            />

            <Carousel.Caption>
              {/* <h3>Second slide label</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p> */}
            </Carousel.Caption>
          </Carousel.Item>
          <Carousel.Item>
            <img
              className="d-block w-100"
              src="https://images.hdqwalls.com/download/hard-candy-trap-4k-8r-1280x300.jpg"
              alt="Third slide"
            />

            <Carousel.Caption>
              {/* <h3>Third slide label</h3>
            <p>
              Praesent commodo cursus magna, vel scelerisque nisl consectetur.
            </p> */}
            </Carousel.Caption>
          </Carousel.Item>
        </Carousel>

        <div className="prod_conf">
          {datap.map((i, e) => (
            <Product
              id={i._id}
              title={i.name}
              price={i.price}
              rating={i.rating}
              image={i.image}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

export default Banner;
