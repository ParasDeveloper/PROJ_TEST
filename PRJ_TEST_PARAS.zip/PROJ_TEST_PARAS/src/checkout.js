import React, { useState } from "react";
import { useStateValue } from "./StateProvider";
import "./checkout.css";
import CheckoutProduct from "./CheckoutProduct";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link,
  Redirect,
} from "react-router-dom";

function Checkout() {
  const [chk, setchk] = useState(false);
  const [state, dispatch] = useStateValue();
  console.log(state.cart);
  var amount_1 = 0;
  var amount_2 = 0;
  const amount_add_event = (event) => {
    amount_2 = amount_2 + 50;
    if (state.user.first_name != "Guest") {
      dispatch({
        type: "ADD_AMOUNT",
        items: amount_2,
      });
      dispatch({
        type: "ClearCart",
      });
      setchk(true);
    } else {
      alert("Please login and user email:abc@gmail.com and password:123456 ");
    }
  };
  // console.log(state.cart.length);

  return (
    <div className="main_header_chkout">
      <div className="checkout">
        {state.cart.length == 0 ? (
          <p className="cart_header">Your basket is Empty</p>
        ) : (
          <p className="cart_header">Your basket here</p>
        )}
        {state.cart.map((item) => (
          <CheckoutProduct
            id={item.id}
            title={item.title}
            image={item.image}
            price={item.price}
            rating={item.rating}
            quantity={item.quantity}
          />
        ))}
      </div>
      {state.cart.length != 0 ? (
        <div className="deliver_box">
          {state.cart.map((item, index) => {
            amount_2 = amount_2 + item.quantity * item.price;
          })}
          Total Cart Amount:₹{amount_2}
          <br />
          delivery:₹{50}
          <br />
          Subtotal:₹{amount_2 + 50}
          <br />
          {chk ? <Redirect to="./order_success" /> : true}
          <button className="button-align" onClick={amount_add_event}>
            Place Order
          </button>
        </div>
      ) : (
        true
      )}
    </div>
  );
}

export default Checkout;
