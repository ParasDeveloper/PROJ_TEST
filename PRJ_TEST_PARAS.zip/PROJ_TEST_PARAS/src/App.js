import React from "react";
import Header from "./Header";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link,
  Redirect,
} from "react-router-dom";
import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import Banner from "./banner";
import Checkout from "./checkout";
import Login from "./login";
import Ordersuccess from "./Ordersuccess";

function App() {
  return (
    <Router>
      <Switch>
        <Route exact path="/">
          <Redirect to="/home" />
        </Route>
        <Route path="/home">
          <Header />
          <Banner />
        </Route>
        <Route path="/checkout">
          <Header />
          <Checkout />
        </Route>
        <Route path="/login">
          <Header />
          <Login />
        </Route>

        <Route path="/order_success">
          <Header />
          <Ordersuccess />
        </Route>
      </Switch>
    </Router>
  );
}

export default App;
