import React, { useState } from "react";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import "./header.css";
import SearchIcon from "@material-ui/icons/Search";
import ShoppingBasketIcon from "@material-ui/icons/ShoppingBasket";
import { useStateValue } from "./StateProvider";
import {
  Nav,
  Navbar,
  NavDropdown,
  FormControl,
  Button,
  Form,
} from "react-bootstrap";

function Header() {
  const [state, dispatch] = useStateValue();

  const Userclear = () => {
    dispatch({
      type: "ADD_USER",
      items: {
        user: { first_name: "Guest" },
        cart: [],
      },
    });
  };

  return (
    <div className="header_banner">
      <Navbar bg="light" expand="lg">
        <Link to="/home">
          <Navbar.Brand href="#home">
            StudyRoom.live Merchandise Store
          </Navbar.Brand>
        </Link>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="mr-auto"></Nav>
          <Form inline>
            <div type="text" placeholder="Search" className="mr-sm-2" />
            <Link to="/login">
              <Button variant="outline-primary">
                Hello {state.user.first_name}
              </Button>
            </Link>
            {state.user.first_name == "Guest" ? (
              <>
                <Link to="/login">
                  <Button variant="outline-dark">Login</Button>
                </Link>
              </>
            ) : (
              <>
                <Button variant="outline-dark" onClick={Userclear}>
                  Logout
                </Button>
              </>
            )}
            <Link to="/checkout">
              <Button variant="outline-success">
                {" "}
                <ShoppingBasketIcon />
                {state.total}
              </Button>
            </Link>
          </Form>
        </Navbar.Collapse>
      </Navbar>
    </div>
  );
}

export default Header;
