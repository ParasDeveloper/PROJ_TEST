export const initialState = {
  cart: [],
  user: { first_name: "Guest" },
  total: 0,

  amount: 0,
};

function reducer(state, action) {
  switch (action.type) {
    case "ADD_USER":
      state.user = action.items.user;

      return { ...state };
      break;
    case "ClearCart":
      state.cart = [];

      return { ...state };
      break;
    case "ADD_TO_BASKET":
      if (state.cart.length == 0) {
        state.cart.push(action.items);
        state.total += 1;
      } else {
        var a = 0;
        var x = 0;

        state.cart.map((item, index) => {
          if (item.id == action.items.id && x == 0) {
            item.quantity = item.quantity + 1;
            a = a + 1;
            x = x + 1;
            state.total = state.total + 1;
            console.log(state.total);
          }

          if (state.cart.length == index + 1 && a < 1) {
            console.log("b called");
            state.cart.push(action.items);
            state.total += 1;
            x = x + 1;
          }
        });
      }
      //    console.log(state.total)
      return { ...state };
      break;
    case "REMOVE_FROM_BASKET":
      if (state.cart.length == 0) {
        return { ...state };
        break;
      } else {
        var k = undefined;
        state.cart.map((item, index) => {
          if (item.id == action.items.id) {
            item.quantity -= 1;
            console.log(item.quantity);
            if (item.quantity <= 0) {
              k = index;
            } else {
              state.total -= 1;
            }
          }
        });
        if (k != undefined) {
          state.cart.splice(k, 1);
          state.total -= 1;
        }
      }
      // console.log(state.total)
      return { ...state };
      console.log(state.total);
      break;
    case "ADD_AMOUNT":
      return { ...state, amount: action.items };
      break;
  }
}
export default reducer;
