import React, { useState } from "react";
import "./login.css";
import { useStateValue } from "./StateProvider";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link,
  Redirect,
} from "react-router-dom";
import {
  Nav,
  Navbar,
  NavDropdown,
  FormControl,
  Button,
  Form,
  Alert,
} from "react-bootstrap";

function Login() {
  let [state, dispatch] = useStateValue();

  const [email, setemail] = useState("");
  const [password, setpassword] = useState("");

  const [message, setmessage] = useState("");
  const [stat, setstat] = useState(false);

  const feildsetter = (event) => {
    if (event.target.id == "email") {
      setemail(event.target.value);
    } else {
      setpassword(event.target.value);
    }
  };

  const submitpress = (event) => {
    event.preventDefault();
    if (email == "abc@gmail.com" && password == "123456") {
      dispatch({
        type: "ADD_USER",
        items: { user: { first_name: "abc" } },
      });
      setstat(true);
    } else {
      setmessage("Please use email as email:abc@gmail.com and password:123456");
    }
  };

  return (
    <div>
      <Form>
        <Form.Group controlId="formBasicEmail">
          <Form.Label>Email address</Form.Label>
          <Form.Control
            value={email}
            onChange={feildsetter}
            type="text"
            id="email"
            type="email"
            placeholder="Enter email"
          />
          <Form.Text className="text-muted">
            We'll never share your email with anyone else.
          </Form.Text>
        </Form.Group>

        <Form.Group controlId="formBasicPassword">
          <Form.Label>Password</Form.Label>
          <Form.Control
            value={password}
            onChange={feildsetter}
            type="password"
            id="password"
            type="password"
            placeholder="Password"
          />
        </Form.Group>

        <Button variant="primary" onClick={submitpress} type="submit">
          Submit
        </Button>
      </Form>

      {state.user.first_name != "Guest" ? <Redirect to="/home" /> : false}

      {message ? <Alert variant="danger">{message} </Alert> : false}
    </div>
  );
}

export default Login;
